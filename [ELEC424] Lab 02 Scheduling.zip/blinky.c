#ifdef __cplusplus
extern "C"{
#endif
  
#include "stm32f10x.h"
#include "stm32f10x_flash.h"
#include "stm32f10x_flash.c"
#include "stm32f10x_tim.h"
#include "stm32f10x_tim.c"
#include "misc.h"
#include "misc.c"
#include "lab2.h"
/*-------------function defines-------------*/
void APB_Clock_Config(void);
void GPIO_Config(void);
void CLOCK_Config(void);
void NVIC_TIMER_Config(void);
void FLASH_Config(void);
void TIM_Config(int TimerPeriodIn);
void error_loop(void);

/*-------------stucture defines-------------*/
GPIO_InitTypeDef	GPIO_InitStructure;
ErrorStatus 		HSEStartUpStatus;
RCC_ClocksTypeDef	RCC_Clocks;
TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
NVIC_InitTypeDef 	NVIC_InitStructure;
MotorSpeeds motor_speed;

#ifdef __cplusplus
}
#endif

/*------------macro&constant defines--------*/
#define TICKS_PER_SECOND 3600000
#define PWM_UPDATE_FREQ 40
#define ERROR_LOOP error_loop();
#define DUTYCYCLE_HIGH 70
#define DUTYCYCLE_MID  40
#define DUTYCYCLE_LOW  20
#define DUTYCYCLE_VERY_LOW 5

/*-------------variable defines-------------*/
int i;
int j=0,l=0,m=0,n=0;
uint16_t timerPeriod = 0;
uint16_t pwm_counter_limit=0;
uint16_t pwm_counter = 0;
uint16_t tim4_counter=0;
//uint16_t current_motor  = 0;
uint16_t motors[] ={GPIO_Pin_1,GPIO_Pin_0,GPIO_Pin_9,GPIO_Pin_8};
//uint16_t motor_state[]={0,0,0,0};
int main (void){   
 
   FLASH_Config();
  CLOCK_Config();
 RCC_GetClocksFreq(&RCC_Clocks);
 APB_Clock_Config();
 NVIC_TIMER_Config();
 GPIO_Config();

timerPeriod = (RCC_Clocks.PCLK1_Frequency / (PWM_UPDATE_FREQ*100) ) ;
pwm_counter_limit = DUTYCYCLE_VERY_LOW;

 TIM_Config(timerPeriod);

  GPIO_WriteBit(GPIOB,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_8|GPIO_Pin_9,0);
  while(1){
   asm("nop");
  }

}

void GPIO_Config(void){
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_NoJTRST,ENABLE);
  GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_8|GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB,&GPIO_InitStructure);
  GPIO_WriteBit(GPIOB,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_8|GPIO_Pin_9,0);
  GPIO_WriteBit(GPIOB,GPIO_Pin_4|GPIO_Pin_5,1);
 }
void FLASH_Config(void){
 // enable flash buffer
  FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
  // change latency
  FLASH_SetLatency(FLASH_Latency_2);

}
void CLOCK_Config(void){

  RCC_DeInit();
  // enable HSE wait for success
  RCC_HSEConfig(RCC_HSE_ON);
  HSEStartUpStatus = RCC_WaitForHSEStartUp();
  if (HSEStartUpStatus != SUCCESS){
    ERROR_LOOP
  };
  
  // setup HCLK and PCLKS

  RCC_HCLKConfig(RCC_SYSCLK_Div1);
  RCC_PCLK1Config(RCC_HCLK_Div4);
  RCC_PCLK2Config(RCC_HCLK_Div4);
  
  //configure PLL
  RCC_PLLConfig(RCC_PLLSource_HSE_Div1,RCC_PLLMul_9);
  RCC_PLLCmd(ENABLE);
 
 while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY)==RESET){}
 RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
 
 while(RCC_GetSYSCLKSource()!=0x08){}

}
void TIM_Config(int TimerPeriodIn){
  /* Time Base configuration */
  TIM_DeInit(TIM2);
  TIM_TimeBaseStructure.TIM_Prescaler = 0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = TimerPeriodIn;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

  TIM_ClearFlag(TIM2,TIM_FLAG_Update);
  TIM_ITConfig(TIM2,TIM_IT_Update|TIM_IT_Trigger,ENABLE);


  TIM_Cmd(TIM2, ENABLE);

  TIM_DeInit(TIM3);
  long temp = RCC_Clocks.PCLK1_Frequency*2/32768;
  TIM_TimeBaseStructure.TIM_Prescaler = temp;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 0xFFFF;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
  TIM_ClearFlag(TIM3,TIM_FLAG_Update);
  TIM_ITConfig(TIM3,TIM_IT_Update|TIM_IT_Trigger,ENABLE);


 /* TIM1 counter enable */
  TIM_Cmd(TIM3, ENABLE);

  TIM_DeInit(TIM4);
  TIM_TimeBaseStructure.TIM_Prescaler = temp;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 0xFFFF/100;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
  TIM_ClearFlag(TIM4,TIM_FLAG_Update);
  TIM_ITConfig(TIM4,TIM_IT_Update|TIM_IT_Trigger,ENABLE);


 /* TIM1 counter enable */
  TIM_Cmd(TIM4, ENABLE);

}

void APB_Clock_Config(void){
  // open peripheral clock
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2|RCC_APB1Periph_TIM3|RCC_APB1Periph_TIM4,ENABLE);
}

void NVIC_TIMER_Config(void){
   NVIC_SetVectorTable(NVIC_VectTab_FLASH,0x0);
   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
   NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
   NVIC_Init(&NVIC_InitStructure);

   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
   NVIC_Init(&NVIC_InitStructure);



}
void TIM2_IRQHandler(void){
int k;
l++;
if (pwm_counter==pwm_counter_limit){
 for (k=0;k<=3;k++){
  
  GPIO_WriteBit(GPIOB,(motors[k]),0);
   
  }
}
if (pwm_counter ==0){
// update motor on off state
  if (motor_speed.m1==1){
  GPIO_WriteBit(GPIOB,(motors[0]),1);
  }
  if (motor_speed.m2==1){
  GPIO_WriteBit(GPIOB,(motors[1]),1);
  }
  if (motor_speed.m3==1){
  GPIO_WriteBit(GPIOB,(motors[2]),1);
  }
  if (motor_speed.m4==1){
  GPIO_WriteBit(GPIOB,(motors[3]),1);
  }
}
pwm_counter++;
if (pwm_counter ==100){
pwm_counter=0;
}

TIM_ClearFlag(TIM2,TIM_FLAG_Update);

}
void TIM3_IRQHandler(void){
//one per second

//green light
if (n==0 ||n == 2){
GPIO_WriteBit(GPIOB,GPIO_Pin_5,0);
}
else{
GPIO_WriteBit(GPIOB,GPIO_Pin_5,1);
}

if (n==0){
GPIO_WriteBit(GPIOB,GPIO_Pin_4,0);
}
else{
GPIO_WriteBit(GPIOB,GPIO_Pin_4,1);
}
n++;
if (n==4){
 n= 0;
}

calculateOrientation();
updatePid(&motor_speed);
TIM_ClearFlag(TIM3,TIM_FLAG_Update);
/************Lab2 part2*************


GPIO_WriteBit(GPIOB,(motors[current_motor]),0);
current_motor++;
current_motor %=4;
if (pwm_counter<=pwm_counter_limit){
  GPIO_WriteBit(GPIOB,(motmake opors[current_motor]),1);
}


************************************/

}


void TIM4_IRQHandler(void){
m++;
//one per 10ms
detectEmergency();
 if(tim4_counter == 0){
refreshSensorData();
}
tim4_counter++;
if (tim4_counter ==10){
//one per 100ms
tim4_counter = 0;
}
TIM_ClearFlag(TIM4,TIM_FLAG_Update);
}

void error_loop(void){
  while(1){}
}
