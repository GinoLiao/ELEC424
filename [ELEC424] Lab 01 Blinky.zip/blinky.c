#ifdef __cplusplus
extern "C"{
#endif

#include "stm32f10x.h"
/*-------------constant defines-------------*/
#define TICKS_PER_SECOND 4000000      //f=8MHz, so 4M is half a second

/*-------------stucture defines-------------*/
GPIO_InitTypeDef GPIO_InitStructure;

/*-------------variable defines-------------*/
int i;

int main (void){
  // GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE); 
  // Enable peripheral clock
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  // initilaize GPIO pin 5
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  // flash
 GPIO_WriteBit(GPIOB,GPIO_Pin_5,0);
  
  while(1){

     for(i=0;i<TICKS_PER_SECOND;i++){
       asm("nop");
     }
     //pin 5 low
     GPIO_WriteBit(GPIOB,GPIO_Pin_5,1);

     for(i=0;i<TICKS_PER_SECOND;i++){
       asm("nop");
     }
     //pin 5 high
     GPIO_WriteBit(GPIOB,GPIO_Pin_5,0);

}

}
#ifdef __cplusplus
}
#endif
