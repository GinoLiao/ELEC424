// lab2.c contains codes for lab 0-2
#include "blinky.h"
/*-------------function defines-------------*/
void APB_Clock_Config(void);
void GPIO_Config(void);
void CLOCK_Config(void);
void FLASH_Config(void);
void duty_config(uint16_t CCR_M1,uint16_t CCR_M2,uint16_t CCR_M3,uint16_t CCR_M4);
void error_loop(void);
void change_duty(int M1,int M2,int M3, int M4);
void update_motor(MotorSpeeds motor_speed,int utyCycle);
/*--------------variable defines-------------*/

// for each full duty cycle we have periodTIM ticks
#define periodTIM 999
// prescaler to change update frequency
#define prescaleTIM 5

// config GPIO Pins
void GPIO_Config(void){
GPIO_PinRemapConfig(GPIO_FullRemap_TIM3, ENABLE);
GPIO_PinRemapConfig(GPIO_Remap_TIM4, ENABLE);
  GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4|GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB,&GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_8|GPIO_Pin_9;			
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		
	GPIO_Init(GPIOB, &GPIO_InitStructure);


  GPIO_WriteBit(GPIOB,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_8|GPIO_Pin_9,0);

  GPIO_WriteBit(GPIOB,GPIO_Pin_4|GPIO_Pin_5,1);
 }

void FLASH_Config(void){
 // enable flash buffer
  FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
  // change latency
  FLASH_SetLatency(FLASH_Latency_2);

}
void CLOCK_Config(void){

  RCC_DeInit();
  // enable HSE wait for success
  RCC_HSEConfig(RCC_HSE_ON);
  HSEStartUpStatus = RCC_WaitForHSEStartUp();
  if (HSEStartUpStatus != SUCCESS){
    ERROR_LOOP
  };
  
  // setup HCLK and PCLKS

  RCC_HCLKConfig(RCC_SYSCLK_Div1);
  RCC_PCLK1Config(RCC_HCLK_Div2);
  RCC_PCLK2Config(RCC_HCLK_Div1);
  
  //configure PLL
  RCC_PLLConfig(RCC_PLLSource_HSE_Div2,RCC_PLLMul_9);
  RCC_PLLCmd(ENABLE);
 
 while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY)==RESET){}
 RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
 
 while(RCC_GetSYSCLKSource()!=0x08){}

}
void duty_config(uint16_t CCR_M1,uint16_t CCR_M2,uint16_t CCR_M3,uint16_t CCR_M4){


	TIM_DeInit(TIM3);			/*reset TIM3*/

	TIM_TimeBaseStructure.TIM_Period =periodTIM; 
	TIM_TimeBaseStructure.TIM_Prescaler =prescaleTIM; 	
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;	//
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//count up
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseStructure);	//initialize interrupt
	TIM_ClearFlag(TIM3,TIM_FLAG_Update);	//clear TIM3 interrupt flag//
	TIM_ITConfig(TIM3,TIM_IT_Update|TIM_IT_Trigger,ENABLE); //enable TIM3 interrupt
	

	TIM_DeInit(TIM4);			/*reset TIM3*/

	TIM_TimeBaseStructure.TIM_Period =periodTIM;  
	TIM_TimeBaseStructure.TIM_Prescaler =prescaleTIM; 	
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;	//
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//count up
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseStructure);	//initialize interrupt
	TIM_ClearFlag(TIM4,TIM_FLAG_Update);	//clear TIM3 interrupt flag//
	TIM_ITConfig(TIM4,TIM_IT_Update|TIM_IT_Trigger,ENABLE); //enable TIM3

// pin 0pwm
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  	TIM_OCInitStructure.TIM_Pulse = CCR_M2;
  	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  	TIM_OC3Init(TIM3, &TIM_OCInitStructure);
  	TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);
// pin 1 pwm
  	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  	TIM_OCInitStructure.TIM_Pulse = CCR_M1;
  	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  	TIM_OC4Init(TIM3, &TIM_OCInitStructure);
  	TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable);
//pin 8 pwm
  	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  	TIM_OCInitStructure.TIM_Pulse = CCR_M4;
  	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  	TIM_OC3Init(TIM4, &TIM_OCInitStructure);
  	TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);
//pin 9 pwm
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  	TIM_OCInitStructure.TIM_Pulse = CCR_M3;
  	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  	TIM_OC4Init(TIM4, &TIM_OCInitStructure);
  	TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable);
	TIM_Cmd(TIM3,ENABLE);			/*TIM3 switch on*/
	TIM_Cmd(TIM4,ENABLE);

}

void APB_Clock_Config(void){
  // open peripheral clock
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2|RCC_APB1Periph_TIM3|RCC_APB1Periph_TIM4,ENABLE);
}

// change duty cycle
void change_duty(int M1,int M2,int M3, int M4){
	uint16_t CCR_M1,CCR_M2,CCR_M3,CCR_M4;

// calculate ccr value, which is dutycycle * (periodTim+1)
	CCR_M1=(uint16_t)(M1*(periodTIM+1)/100);
	CCR_M2=(uint16_t)(M2*(periodTIM+1)/100);
	CCR_M3=(uint16_t)(M3*(periodTIM+1)/100);
	CCR_M4=(uint16_t)(M4*(periodTIM+1)/100);
// re config
        duty_config(CCR_M1,CCR_M2,CCR_M3,CCR_M4);
}


// update motor state
void update_motor(MotorSpeeds motor_speed,int dutyCycle){

change_duty(dutyCycle*motor_speed.m1,dutyCycle*motor_speed.m2,dutyCycle*motor_speed.m3,dutyCycle*motor_speed.m4);
}


void error_loop(void){
  while(1){}
}

