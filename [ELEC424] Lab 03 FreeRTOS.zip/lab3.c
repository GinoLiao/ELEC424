#include "blinky.h"
void create_tasks(void);
void detectEmergency_task(void *pIn);
void refreshSensorData_task(void *pIn);
void calculateOrientation_task(void *pIn);
void updatePid_task(void *pIn);
void debugInfo_task(void *pIn);
void led_task(void *pIn);
xSemaphoreHandle syncSemaphore;
/********************************/
#define main_TASK_PRIORITY 			tskIDLE_PRIORITY
#define detectEmergency_TASK_PRIORITY 		(main_TASK_PRIORITY+4)
#define refreshSensorData_TASK_PRIORITY		(main_TASK_PRIORITY+3)
#define calculateOrientation_TASK_PRIORITY	(main_TASK_PRIORITY+2)
#define updatePid_TASK_PRIORITY			(main_TASK_PRIORITY+2)
#define debugInfo_TASK_PRIORITY			(main_TASK_PRIORITY+1)
#define led_TASK_PRIORITY			(main_TASK_PRIORITY+6)
/************************/

void create_tasks(void){

  xTaskCreate(detectEmergency_task,(portCHAR *) "foobar",configMINIMAL_STACK_SIZE,NULL,detectEmergency_TASK_PRIORITY,NULL);
  xTaskCreate(refreshSensorData_task,(portCHAR *) "foobar",configMINIMAL_STACK_SIZE,NULL,refreshSensorData_TASK_PRIORITY,NULL);
  xTaskCreate(calculateOrientation_task,(portCHAR *) "foobar",configMINIMAL_STACK_SIZE,NULL,calculateOrientation_TASK_PRIORITY,NULL);
  xTaskCreate(updatePid_task,(portCHAR *) "foobar",configMINIMAL_STACK_SIZE,NULL,updatePid_TASK_PRIORITY,NULL);
  xTaskCreate(debugInfo_task,(portCHAR *) "foobar",configMINIMAL_STACK_SIZE,NULL,debugInfo_TASK_PRIORITY,NULL);
  xTaskCreate(led_task,(portCHAR *) "foobar",configMINIMAL_STACK_SIZE,NULL,led_TASK_PRIORITY,NULL);
  vSemaphoreCreateBinary(syncSemaphore);
test = 1;
// give control to RTOS scheduler
vTaskStartScheduler();
test =2;
}

// emergency task, 10ms
void detectEmergency_task(void *pIn){
while(1){
detectEmergency();
vTaskDelay(10);
 }
}

//refresh data task, 100ms
void refreshSensorData_task(void *pIn){
while(1){
refreshSensorData();
xSemaphoreGive(syncSemaphore);
vTaskDelay(100);
}
}
// claculate orientationtask 100ms
void calculateOrientation_task(void *pIn){
while(1){
if (xSemaphoreTake(syncSemaphore,0)==pdTRUE);
calculateOrientation();
vTaskDelay(100);
}

}
// update pid task
void updatePid_task(void *pIn){
while(1){
updatePid(&motor_speed);
update_motor(motor_speed,DUTYCYCLE_VERY_LOW);
vTaskDelay(1000);
}
}
void debugInfo_task(void *pIn){
while(1){
logDebugInfo();
vTaskDelay(1000);
}
}

// led task, red light was not finished yet
void led_task(void *pIn){
while(1){
  GPIO_WriteBit(GPIOB,GPIO_Pin_5,0);
  vTaskDelay(1000);
  GPIO_WriteBit(GPIOB,GPIO_Pin_5,1);
  vTaskDelay(1000);
  //GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable,ENABLE);
//  GPIO_WriteBit(GPIOB,GPIO_Pin_4,0);
  //GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable,DISABLE);
  GPIO_WriteBit(GPIOB,GPIO_Pin_5,0);
  vTaskDelay(1000);
  GPIO_WriteBit(GPIOB,GPIO_Pin_5,1);
  vTaskDelay(1000);
  //GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable,ENABLE);
  //GPIO_WriteBit(GPIOB,GPIO_Pin_4,1);
  //GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable,DISABLE);
}
}
