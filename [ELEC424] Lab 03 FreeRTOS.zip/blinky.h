// header for blinky.c

#include "stm32f10x.h"
#include "stm32f10x_flash.h"
#include "stm32f10x_tim.h"
#include "misc.h"
#include "lab3.h"

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "list.h"
#include "queue.h"



/*-------------function defines-------------*/
int main(void);
/*-------------stucture defines-------------*/
GPIO_InitTypeDef	GPIO_InitStructure;
ErrorStatus 		HSEStartUpStatus;
RCC_ClocksTypeDef	RCC_Clocks;
TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
NVIC_InitTypeDef 	NVIC_InitStructure;
MotorSpeeds 		motor_speed;
TIM_OCInitTypeDef  	TIM_OCInitStructure;

/*------------macro&constant defines--------*/
#define ERROR_LOOP error_loop();
#define DUTYCYCLE_HIGH 70
#define DUTYCYCLE_MID  40
#define DUTYCYCLE_LOW  20
#define DUTYCYCLE_VERY_LOW 10


/*-------------variable defines-------------*/

