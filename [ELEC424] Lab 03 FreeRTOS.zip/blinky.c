
#include "blinky.h"

/*---------------------main-----------------*/
int main (void){   
 
 FLASH_Config();
 CLOCK_Config();
 RCC_GetClocksFreq(&RCC_Clocks);
 APB_Clock_Config();
 GPIO_Config();
create_tasks();

  while(1){
   asm("nop");
  }


}


